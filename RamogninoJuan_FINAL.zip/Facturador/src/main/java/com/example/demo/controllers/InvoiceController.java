package com.store.billing.controllers;

import com.store.billing.entities.Bill;
import com.store.billing.entities.BillItem;
import com.store.billing.entities.Product;
import com.store.billing.services.BillService;
import com.store.billing.services.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    @Autowired
    private BillService billService;

    @Autowired
    private ProductService productService;

    @Operation(summary = "Create a new bill", description = "Generate a new bill")
    @ApiResponse(responseCode = "201", description = "Bill created successfully")
    @ApiResponse(responseCode = "500", description = "Server error")
    @PostMapping(consumes = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Bill> createBill(@RequestBody Bill bill) {
        try {
            Bill newBill = billService.save(bill);
            return ResponseEntity.status(HttpStatus.CREATED).body(newBill);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Retrieve all bills", description = "Fetch a list of all bills")
    @ApiResponse(responseCode = "200", description = "List of all bills fetched successfully")
    @ApiResponse(responseCode = "404", description = "No bills found")
    @GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Iterable<Bill>> getAllBills() {
        Iterable<Bill> bills = billService.getAllBills();
        return ResponseEntity.ok(bills);
    }

    @Operation(summary = "Get bill by ID", description = "Fetch a bill by its unique ID")
    @ApiResponse(responseCode = "200", description = "Bill found successfully")
    @ApiResponse(responseCode = "404", description = "Bill not found")
    @GetMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Optional<Bill>> getBillById(@PathVariable UUID id) {
        Optional<Bill> bill = billService.getById(id);
        if (bill.isPresent()) {
            return ResponseEntity.ok(bill);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Optional.empty());
        }
    }

    @Operation(summary = "Add items to bill", description = "Add items to a specific bill")
    @ApiResponse(responseCode = "200", description = "Items added to the bill successfully")
    @ApiResponse(responseCode = "404", description = "Bill or product not found")
    @ApiResponse(responseCode = "500", description = "Server error")
    @PostMapping("/{billId}/items")
    public ResponseEntity<?> addItemsToBill(
            @PathVariable UUID billId,
            @RequestBody List<BillItem> items) {

        Optional<Bill> billOpt = billService.getById(billId);

        if (!billOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Bill not found");
        }

        Bill bill = billOpt.get();
        bill.clearItems();

        try {
            for (BillItem item : items) {

                if (item.getProduct() == null || item.getProduct().getId() == null) {
                    throw new RuntimeException("Product not found with ID");
                }

                Optional<Product> productOpt = productService.getById(item.getProduct().getId());

                if (!productOpt.isPresent()) {
                    throw new RuntimeException("Product not found with ID: " + item.getProduct().getId());
                }

                item.setProduct(productOpt.get());
                item.setBill(bill);
                item.setSubtotal();

                billService.addItemToBill(bill, item);
            }

            bill.calculateTotal();
            Bill updatedBill = billService.save(bill);

            return ResponseEntity.status(HttpStatus.CREATED).body(updatedBill);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while adding items");
        }
    }

    @Operation(summary = "Update an existing bill", description = "Update details of a bill by its ID")
    @ApiResponse(responseCode = "200", description = "Bill updated successfully")
    @ApiResponse(responseCode = "404", description = "Bill not found")
    @PutMapping(value = "/{id}", consumes = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Bill> updateBill(@PathVariable UUID id, @RequestBody Bill bill) {
        Optional<Bill> existingBill = billService.getById(id);
        if (!existingBill.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }

        bill.setId(id);
        Bill updatedBill = billService.save(bill);
        return ResponseEntity.ok(updatedBill);
    }

    @Operation(summary = "Delete a bill", description = "Delete a specific bill by ID")
    @ApiResponse(responseCode = "204", description = "Bill deleted successfully")
    @ApiResponse(responseCode = "404", description = "Bill not found")
    @DeleteMapping(value = "/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<Void> deleteBill(@PathVariable UUID id) {
        try {
            billService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
