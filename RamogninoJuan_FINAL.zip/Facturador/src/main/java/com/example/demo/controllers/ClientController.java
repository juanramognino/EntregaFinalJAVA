package com.store.management.controllers;

import com.store.management.entities.Customer;
import com.store.management.services.CustomerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Operation(summary = "Retrieve all customers", description = "Fetch all registered customers from the database")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved all customers")
    @ApiResponse(responseCode = "404", description = "No customers found")
    @ApiResponse(responseCode = "500", description = "Server error")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Iterable<Customer>> getAllCustomers() {
        Iterable<Customer> customers = customerService.getAllCustomers();
        return ResponseEntity.ok(customers);
    }

    @Operation(summary = "Get customer by ID", description = "Fetch a customer by their unique ID")
    @ApiResponse(responseCode = "200", description = "Customer found successfully")
    @ApiResponse(responseCode = "404", description = "Customer not found")
    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Customer> getCustomerById(@PathVariable UUID id) {
        Optional<Customer> customer = customerService.getCustomerById(id);
        return customer.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(null));
    }

    @Operation(summary = "Create a new customer", description = "Register a new customer into the system")
    @ApiResponse(responseCode = "200", description = "Customer created successfully")
    @ApiResponse(responseCode = "400", description = "Invalid customer data")
    @ApiResponse(responseCode = "500", description = "Internal server error")
    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer newCustomer) {
        if (newCustomer.getName() == null || newCustomer.getName().trim().isEmpty()) {
            return ResponseEntity.badRequest().body(null); // Ensuring customer name is valid
        }
        try {
            Customer createdCustomer = customerService.saveCustomer(newCustomer);
            return ResponseEntity.ok(createdCustomer);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(null);
        }
    }

    @Operation(summary = "Update customer details", description = "Update information of an existing customer")
    @ApiResponse(responseCode = "200", description = "Customer updated successfully")
    @ApiResponse(responseCode = "404", description = "Customer not found")
    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Customer> updateCustomer(@PathVariable UUID id, @RequestBody Customer updatedCustomer) {
        Optional<Customer> existingCustomer = customerService.getCustomerById(id);
        if (existingCustomer.isPresent()) {
            updatedCustomer.setId(id);
            Customer customer = customerService.saveCustomer(updatedCustomer);
            return ResponseEntity.ok(customer);
        } else {
            return ResponseEntity.status(404).body(null);
        }
    }

    @Operation(summary = "Delete a customer", description = "Remove a customer from the system by their ID")
    @ApiResponse(responseCode = "200", description = "Customer deleted successfully")
    @ApiResponse(responseCode = "404", description = "Customer not found")
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable UUID id) {
        try {
            customerService.deleteCustomerById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).build();
        }
    }
}
