package com.example.demo.repositories;

import com.example.demo.entities.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ClientRepository extends JpaRepository<Client, UUID> {

    // Buscar cliente por su DNI
    Optional<Client> findByDni(String dni);

    // Buscar cliente por su correo electrónico
    Optional<Client> findByEmail(String email);

    // Eliminar cliente por su ID
    void deleteById(UUID id);

    // Buscar cliente por su ID
    Optional<Client> findById(UUID id);
}
