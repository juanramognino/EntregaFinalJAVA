package com.example.demo.loaders;

import com.example.demo.entities.Client;
import com.example.demo.entities.Product;
import com.example.demo.services.ClientService;
import com.example.demo.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
public class ClientProductsDataLoader implements CommandLineRunner {

    @Autowired
    private final ClientService clientService;

    @Autowired
    private final ProductService productService;

    public ClientProductsDataLoader(ClientService clientService, ProductService productService) {
        this.clientService = clientService;
        this.productService = productService;
    }

    @Override
    public void run(String... args) throws Exception {
        // Creando clientes con HashMap
        Map<String, Client> clients = new HashMap<>();
        clients.put("cliente1",
                new Client(UUID.fromString("abcd1234-56ef-7890-gh12-ijklmnop1234"), "23456789", "Luis", "Martinez",
                        "luis.martinez@correo.com", "555-1234-5678"));
        clients.put("cliente2",
                new Client(UUID.randomUUID(), "98765432", "Paola", "Fernandez", "paola.fernandez@correo.com", "555-2345-6789"));
        clients.put("cliente3",
                new Client(UUID.randomUUID(), "33445566", "Ricardo", "Lopez", "ricardo.lopez@correo.com", "555-3456-7890"));
        clients.put("cliente4",
                new Client(UUID.randomUUID(), "22334455", "Laura", "Gomez", "laura.gomez@correo.com", "555-4567-8901"));

        // Guardar cada cliente en la base de datos
        for (Map.Entry<String, Client> entry : clients.entrySet()) {
            clientService.save(entry.getValue());
        }

        // Creando productos con HashMap
        Map<String, Product> products = new HashMap<>();
        products.put("producto1", new Product("Portátil", "Portátil de alta gama para trabajo y gaming", 1500.00, 12));
        products.put("producto2", new Product("Teléfono", "Smartphone de última generación con excelentes características", 950.00, 18));
        products.put("producto3", new Product("Auriculares", "Auriculares Bluetooth con cancelación de ruido", 180.00, 25));
        products.put("producto4", new Product("Ratón", "Ratón ergonómico con retroiluminación", 45.00, 30));
        products.put("producto5", new Product("Monitor", "Monitor 4K de 32 pulgadas para diseño gráfico", 450.00, 8));

        // Guardar cada producto en la base de datos
        for (Map.Entry<String, Product> entry : products.entrySet()) {
            productService.save(entry.getValue());
        }
    }
}
