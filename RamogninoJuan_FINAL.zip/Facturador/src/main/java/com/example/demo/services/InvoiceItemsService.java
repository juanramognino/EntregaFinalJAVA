package com.example.demo.services;

import com.example.demo.entities.InvoiceItem;
import com.example.demo.entities.Product;
import com.example.demo.repositories.InvoiceItemRepository;
import com.example.demo.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class InvoiceItemsService {

    @Autowired
    private InvoiceItemRepository repository;

    @Autowired
    private ProductRepository productRepository;

    // Guardar un ítem de factura
    public InvoiceItem saveInvoiceItem(InvoiceItem item) {
        return repository.save(item);
    }

    // Obtener todos los ítems de factura
    public List<InvoiceItem> getAllInvoiceItems() {
        return repository.findAll();
    }

    // Obtener producto por ID
    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    // Obtener ítems de factura por ID de factura
    public List<InvoiceItem> findItemsByInvoiceId(UUID invoiceId) {
        return repository.findByInvoiceId(invoiceId);
    }

    // Eliminar ítem de factura por ID
    public void deleteInvoiceItemById(UUID id) {
        Optional<InvoiceItem> item = repository.findById(id);
        if (item.isPresent()) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("No se encontró el ítem de factura con ID: " + id);
        }
    }
}
