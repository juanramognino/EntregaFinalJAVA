package com.example.demo.services;

import com.example.demo.entities.Product;
import com.example.demo.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private final ProductRepository repository;

    @Autowired
    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    // Guardar un nuevo producto
    public Product saveProduct(Product product) {
        return repository.save(product);
    }

    // Obtener todos los productos
    public List<Product> getAllProducts() {
        return repository.findAll();
    }

    // Obtener producto por ID
    public Optional<Product> getProductById(Long id) {
        return repository.findById(id);
    }

    // Eliminar producto por ID
    public void deleteProductById(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("Producto no encontrado con ID: " + id);
        }
    }

    // Actualizar stock de un producto
    public void updateProductStock(Product product) {
        if (repository.existsById(product.getId())) {
            repository.save(product);
        } else {
            throw new RuntimeException("Producto no encontrado con ID: " + product.getId());
        }
    }
}
