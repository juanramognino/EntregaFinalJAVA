package com.example.demo.repositories;

import com.example.demo.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    // Buscar producto por su ID
    Optional<Product> findById(Long id);

    // Eliminar producto por su ID
    void deleteById(Long id);
}
