package com.example.demo.services;

import com.example.demo.entities.Client;
import com.example.demo.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ClientService {

    @Autowired
    private ClientRepository repository;

    // Guardar un nuevo cliente
    public Client saveClient(Client client) {
        return repository.save(client);
    }

    // Obtener todos los clientes
    public List<Client> getAllClients() {
        return repository.findAll();
    }

    // Obtener cliente por su ID
    public Optional<Client> getClientById(UUID id) {
        return repository.findById(id);
    }

    // Eliminar cliente por su ID
    public void deleteClientById(UUID id) {
        Optional<Client> client = repository.findById(id);
        if (client.isPresent()) {
            repository.deleteById(id);
        } else {
            throw new RuntimeException("No se encontró cliente con ID: " + id);
        }
    }

    // Buscar cliente por DNI
    public Optional<Client> findClientByDni(String dni) {
        return repository.findByDni(dni);
    }

    // Buscar cliente por correo electrónico
    public Optional<Client> findClientByEmail(String email) {
        return repository.findByMail(email);
    }
}
