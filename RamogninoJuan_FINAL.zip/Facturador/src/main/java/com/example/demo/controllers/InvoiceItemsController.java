package com.store.billing.controllers;

import com.store.billing.entities.BillItem;
import com.store.billing.services.BillItemService;
import com.store.billing.services.BillService;
import com.store.billing.services.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/bills")
public class BillItemController {

    @Autowired
    private BillItemService billItemService;

    @Autowired
    private BillService billService;

    @Autowired
    private ProductService productService;

    @Operation(summary = "Retrieve items by bill ID", description = "Retrieve all items related to a specific bill by its ID")
    @ApiResponse(responseCode = "200", description = "OK")
    @ApiResponse(responseCode = "404", description = "Bill not found")
    @ApiResponse(responseCode = "500", description = "Internal Server Error")
    @ApiResponse(responseCode = "400", description = "Invalid Request")
    @ApiResponse(responseCode = "409", description = "Conflict")
    @GetMapping(value = "/{billId}/items", produces = { MediaType.APPLICATION_JSON_VALUE })
    public ResponseEntity<List<BillItem>> getItemsByBillId(@PathVariable UUID billId) {
        List<BillItem> items = billItemService.findByBillId(billId);
        if (items.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(items);
    }

}
