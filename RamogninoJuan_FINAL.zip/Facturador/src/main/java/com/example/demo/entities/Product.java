package com.example.demo.entities;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "product")
@Schema(description = "Entidad que representa un producto", example = "{\"id\":\"00000000-0000-0000-0000-000000000000\",\"name\":\"Itemo 1\",\"description\":\"Descripcion del producto 1\",\"price\":10.0,\"stock\":100}")
public class Item {

    @Schema(description = "Id del producto", example = "1 INT , UUID 00000000-0000-0000-0000-000000000000")
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Schema(description = "Nombre del producto", example = "Itemo 1")
    @Column(nullable = false)
    private String name;

    @Schema(description = "Descripcion del producto", example = "Descripcion del producto 1")
    @Column
    private String description;

    @Schema(description = "Precio del producto", example = "10.0")
    @Column(nullable = false)
    private BigDecimal price;

    @Schema(description = "Stock del producto", example = "100")
    @Column(nullable = false)
    private int stock;

    // Constructor para crear el producto con nombre, descripción, precio y stock
    public Item(String name, String description, BigDecimal price, int stock) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.stock = stock;
    }

    // Métodos manuales para obtener el precio y stock
    public BigDecimal getPrice() {
        return this.price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}
