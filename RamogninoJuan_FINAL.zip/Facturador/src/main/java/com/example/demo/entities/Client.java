package com.example.demo.entities;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Schema(description = "Entidad que representa a un cliente", example = "{\"dni\":\"12345678\",\"name\":\"Juan\",\"lastname\":\"Perez\",\"mail\":\"juanperez@gmail.com\",\"telefono\":\"+56987654321\"}")
@Table(name = "client")
public class Customer {

    @Schema(description = "Id del cliente", example = "00000000-0000-0000-0000-000000000000")
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Schema(description = "DNI del cliente", example = "12345678")
    @Column(nullable = false, unique = true)
    private String dni;

    @Schema(description = "Nombre del cliente", example = "Juan")
    @Column(nullable = false)
    private String name;

    @Schema(description = "Apellido del cliente", example = "Perez")
    @Column(nullable = false)
    private String lastname;

    @Schema(description = "Mail del cliente", example = "juanperez@gmail.com")
    @Column(nullable = false, unique = true)
    private String mail;

    @Schema(description = "Telefono del cliente", example = "+56987654321")
    @Column
    private String telefono;

    public Customer(UUID id) {
        this.id = id;
    }

    public Customer(String dni, String name, String lastname, String mail, String telefono) {
        this.dni = dni;
        this.name = name;
        this.lastname = lastname;
        this.mail = mail;
        this.telefono = telefono;
    }
}
