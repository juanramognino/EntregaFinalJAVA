package com.example.demo.services;

import com.example.demo.entities.Client;
import com.example.demo.entities.Invoice;
import com.example.demo.entities.InvoiceItem;
import com.example.demo.entities.Product;
import com.example.demo.repositories.InvoiceRepository;
import com.example.demo.repositories.ClientRepository;
import com.example.demo.repositories.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.ArrayList;
import java.util.UUID;
import java.util.Date;

@Service
public class InvoiceService {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private TimeApiService timeApiService;

    @Transactional
    public Invoice createInvoice(InvoiceRequest request) {
        // Verificar existencia del cliente
        Optional<Client> clientOpt = clientRepository.findById(request.getClient().getClientId());
        if (!clientOpt.isPresent()) {
            throw new RuntimeException("Cliente no encontrado.");
        }

        Invoice invoice = new Invoice();
        invoice.setClient(clientOpt.get());
        List<InvoiceItem> invoiceItems = new ArrayList<>();

        double totalAmount = 0;
        int totalQuantity = 0;

        for (InvoiceItemRequest itemRequest : request.getLineItems()) {
            Optional<Product> productOpt = productRepository.findById(itemRequest.getProduct().getProductId());
            if (!productOpt.isPresent()) {
                throw new RuntimeException("Producto no encontrado.");
            }

            Product product = productOpt.get();
            if (itemRequest.getQuantity() > product.getStock()) {
                throw new RuntimeException("No hay suficiente stock para el producto: " + product.getName());
            }

            product.setStock(product.getStock() - itemRequest.getQuantity());
            productRepository.save(product);

            InvoiceItem invoiceItem = new InvoiceItem();
            invoiceItem.setProduct(product);
            invoiceItem.setQuantity(itemRequest.getQuantity());
            invoiceItem.setUnitPrice(product.getPrice());
            invoiceItems.add(invoiceItem);

            totalAmount += product.getPrice() * itemRequest.getQuantity();
            totalQuantity += itemRequest.getQuantity();
        }

        invoice.setItems(invoiceItems);
        invoice.setTotalPrice(totalAmount);
        invoice.setTotalQuantity(totalQuantity);

        // Obtener fecha desde el servicio de API de tiempo
        try {
            invoice.setDate(timeApiService.getCurrentDateTime());
        } catch (Exception e) {
            invoice.setDate(new Date());
        }

        return invoiceRepository.save(invoice);
    }
}
